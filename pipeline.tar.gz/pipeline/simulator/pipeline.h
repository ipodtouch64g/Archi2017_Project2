#ifndef Pipeline_h
#define Pipeline_h

void IF();
void ID();
void EXE();
void DM();
void WB();
void nextStage();
#endif
